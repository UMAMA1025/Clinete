function agregarCoche() {}

function mostrarCoches() {  
    // Si no existe la imagen, carga la de por defecto "none.jpg"
    img.onerror = () => { 
      img.onerror = null; 
      img.src = `imagenes/none.jpg`; 
    };
}

function mostrarResumen() {}  

function calcularPromedio(){}

